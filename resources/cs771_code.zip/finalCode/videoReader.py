import numpy as np
import cv2
import os


fileName = os.path.abspath("test.mov")

print fileName

cap = cv2.VideoCapture(fileName)

print cap

print "Video Properties:"
print "\t Width: ",cap.get(cv2.cv.CV_CAP_PROP_FRAME_WIDTH)
print "\t Height: ",cap.get(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT)
print "\t FourCC: ",cap.get(cv2.cv.CV_CAP_PROP_FOURCC)
print "\t Framerate: ",cap.get(cv2.cv.CV_CAP_PROP_FPS)
print "\t Number of Frames: ",cap.get(7)

while(cap.isOpened()):
    ret, frame = cap.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    cv2.imshow('frame',gray)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()