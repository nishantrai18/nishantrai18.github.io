from videoClass import *
import skimage.io as io
import pickle
import datetime
import time
import cv2

def connectedMorph(img):
	kernel = np.ones((5,5),np.uint8)
	imgFinal = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel, iterations = 9)
	imgFinal = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel, iterations = 6)
	return imgFinal

#bg = GetBackground('test2.mov')
#bg = pickle.load(open( "tempBG.p", "rb"))

#pickle.dump(bg, open("tempBG2.p", "wb"))
bg = pickle.load(open( "tempBG.p", "rb"))

areaThreshold = 2000
redFact = 0.5
ddepth = cv2.CV_16S
graybg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
graybg = cv2.resize(graybg ,None, fx=redFact, fy=redFact)
	
saveCount = 0

io.imshow(graybg)
io.show()

cap = VideoCapture('test.mov')
cap.open()

for i in range(0,10):
	(grabbed, frame) = cap.read()
	# Ignore the first 10 frames, mostly due to noise

while True:
	(grabbed, frame) = cap.read()
	text = "Nothing"

	if not grabbed:
		break

	frame = cv2.resize(frame ,None, fx= redFact, fy=redFact)
  	
  	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	frameDelta = cv2.absdiff(graybg, gray)
	thresh = cv2.threshold(frameDelta, 50, 255, cv2.THRESH_BINARY)[1]
 
	# dilate the thresholded image to fill in holes, then find contours on thresholded image

	thresh = cv2.GaussianBlur(thresh, (3, 3), 3)
	
	# sharpThresh = cv2.addWeighted(blurThresh, 1.5, thresh, -0.5, 0)
	# # cv2.imshow('OrigThresh', thresh)
	# cv2.imshow('Normal', thresh)
	# cv2.imshow('Sharp', sharpThresh)
	# thresh = blurThresh


	edgesX = cv2.Sobel(thresh , ddepth, 1, 0, ksize = 3, scale = 1, delta = 0, borderType = cv2.BORDER_DEFAULT)
	edgesX = cv2.convertScaleAbs(edgesX)

	# cv2.imshow('Edges-X', edgesX)

	edgesY = cv2.Sobel(thresh , ddepth, 0, 1, ksize = 3, scale = 1, delta = 0, borderType = cv2.BORDER_DEFAULT)
	edgesY = cv2.convertScaleAbs(edgesY)

	# cv2.imshow('Edges-Y', edgesY)

	# edgesTotal =  edgesY
	edgesTotal = cv2.addWeighted(edgesX, 0.5, edgesY, 0.5, 0)
	cv2.imshow('Edges-Total', edgesTotal)

	imgA = edgesTotal.copy()

	edgesTotal = cv2.GaussianBlur(edgesTotal, (9, 9), 4)
	cv2.imshow('Edges-Total- Blurred', edgesTotal)

	# edgesCanny = cv2.Canny(thresh, 100, 200)
	# cv2.imshow('Edges-Canny', edgesCanny)

	# cv2.imshow('Closed Edges-Canny', connectedMorph(edgesCanny))
	edgesTotal = connectedMorph(edgesTotal)

	# edgesTotal = cv2.threshold(edgesTotal, 10, 255, cv2.THRESH_BINARY)[1]

	cv2.imshow('Closed Edges-Total', edgesTotal)

	thresh = edgesTotal

	imgB = thresh.copy()


	'''
	thresh = cv2.dilate(thresh, None, iterations = 4)
	cv2.imshow('DilateThresh', thresh)

	thresh = cv2.GaussianBlur(thresh, (5, 5), 3)
	cv2.imshow('BlurThresh', thresh)
	'''

	kernel = np.ones((5,5),np.uint8)
	thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations = 9)
	cv2.imshow('MorphClose', thresh)
	thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations = 7)
	cv2.imshow('MorphOpen', thresh)

	# (cnts, _) = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	# cv2.drawContours(gray, cnts, -1, (0,255,0), 3)
	# cv2.imshow('DrawCont', gray)

	(cnts, _) = cv2.findContours(edgesTotal.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	# cv2.drawContours(edgesTotal, cnts, -1, (255,0,0), 3)

	for c in cnts:
		# if the contour is too small, ignore it
		if cv2.contourArea(c) < 15000:
			continue
 
		# compute the bounding box for the contour, draw it on the frame,
		# and update the text
		cv2.drawContours(edgesTotal, [c], -1, (255,0,0), 3)

		# (x, y, w, h) = cv2.boundingRect(c)
		# cv2.rectangle(edgesTotal, (x, y), (x + w, y + h), (255, 0, 0), 2)

	cv2.imshow('DrawContEdges', edgesTotal)

	imgC = edgesTotal.copy()

	#cv2.imshow("Thresh", thresh)
	#cv2.imshow("Frame Delta", frameDelta)
	key = cv2.waitKey(1) & 0xFF
 	
	# if the `q` key is pressed, break from the lop
	if key == ord("q"):
		break
	elif key == ord("p"):
		input("PAUSED FOR NOW... Enter 0-9 to continue")
	elif key == ord("s"):
		saveCount += 1
		print ("Saving the files to objTrack"), saveCount, '*.jpg'
		cv2.imwrite("results/objPlateA" + str(saveCount) + ".jpg", imgA)
		cv2.imwrite("results/objPlateB" + str(saveCount) + ".jpg", imgB)
		cv2.imwrite("results/objPlateC" + str(saveCount) + ".jpg", imgC)

cap.release()
cv2.destroyAllWindows()