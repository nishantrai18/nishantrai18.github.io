import sys,os
from skimage.io import imread,imsave,imshow,show
from skimage.transform import resize
from operator import itemgetter

size = {'Bicycle': (349.2020725388601, 163.6658031088083, 2.4376388912093687), 'Car': (623.0852017937219, 664.7713004484305, 0.9409120895340107), \
'Person': (488.4280701754386, 179.00350877192983, 2.756982070402288), 'Rickshaw': (404.1830065359477, 313.1830065359477, 1.2766964663174343), \
'Autorickshaw': (649.4615384615385, 497.2649572649573, 1.3003383773932282), 'Number-plate': (37.157251908396944, 114.45343511450382, 0.33423864357423577), \
'Motorcycle': (368.8157894736842, 222.3084210526316, 1.8219286898307876)}

sizeDim = 200

# size = {'Car':(200,200)}

# folder = sys.argv[1]

for obj in size.keys():

    outfolder = 'imageData/' + obj +'/resized' + obj

    if not os.path.exists(outfolder):
    	os.makedirs(outfolder)

    for filename in sorted(os.listdir('imageData/' + obj)):
        print filename
        if filename == 'resized' + obj:
            continue
        img = imread('imageData/' + obj +'/' + filename)

        # if img.shape[0]>size[obj][0] and img.shape[1]>size[obj][1]:
            # idx,dim = min(enumerate(img.shape[0:2]),key=itemgetter(1))
            # scale = float(dim)/size[obj][idx]
            # resized_img = resize(img,(int(img.shape[0]/scale +0.01), int(img.shape[1]/scale +0.01)))

            # if idx == 0:
            #     tmp = (resized_img.shape[1] - size[obj][1])/2
            #     resized_img = resized_img[:,tmp:tmp+size[obj][1],:]
            # elif idx == 1:
            #     tmp = (resized_img.shape[1] - size[obj][1])/2
            #     resized_img = resized_img[tmp:tmp+size[obj][1],:,:]

            # imsave(outfolder+'/'+filename, resized_img)

        # if (abs((img.shape[0]*(1.0))/(img.shape[1]*(1.0)) - size[obj][2]) < 0.2 ):

        #     idx, dim = min(enumerate(img.shape[0:2]), key=itemgetter(1))
            
        #     # print idx, dim

        #     scale = float(dim)/sizeDim
        #     # print scale

        #     resized_img = resize(img,(int(img.shape[0]/scale +0.01), int(img.shape[1]/scale +0.01)))

        #     if idx == 0:
        #         tmp = (resized_img.shape[1] - sizeDim)/2
        #         resized_img = resized_img[:,tmp:tmp+sizeDim,:]
        #     elif idx == 1:
        #         tmp = (resized_img.shape[0] - sizeDim)/2
        #         resized_img = resized_img[tmp:tmp+sizeDim,:,:]

        #     imsave(outfolder+'/'+filename, resized_img)
        #     imshow(resized_img)
        #     show()

        if (img.shape[0] > (0.2)*size[obj][0] and img.shape[1] > (0.2)*size[obj][1]) \
            and (abs((img.shape[0]*(1.0))/(img.shape[1]*(1.0)) - size[obj][2]) < 0.3):

            resized_img = resize(img,(sizeDim, sizeDim))

            imsave(outfolder+'/'+filename, resized_img)
            # imshow(resized_img)
            # show()

        else:
            print 'File Ignored'
