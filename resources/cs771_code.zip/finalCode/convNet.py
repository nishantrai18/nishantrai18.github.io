from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D
from keras.optimizers import SGD
import pickle
import numpy as np
from keras.utils import np_utils

np.random.seed(1337)	# Real cool thing, makes it possible to reproduce results

dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle']
# dirPosList = ['Car', 'Person']

def encode(val):
	if (val not in dirPosList):
		return val
	return dirPosList.index(val)

def oneHotEncoder(Y, numClasses):
	ans = []
	for i in range(len(Y)):
		tmp = np.zeros((numClasses,))
		tmp[Y[i]] = 1
		ans.append(tmp)
	ans = np.array(ans)

sizeDim = 100
split = (0.5)
img_rows, img_cols = sizeDim, sizeDim

filterNum = 32
actFunc = 'tanh' # or 'relu', 'sigmoid'
numClasses = 4

batch_size = 128
nb_classes = numClasses
nb_epoch = 3

X, testX, Y, testY = pickle.load(open('rawImgFlipCPMB_' + str(split) + '_' + str(sizeDim) + '.p', 'rb'))

print X.shape
print Y.shape

Y = map(encode, Y)
testY = map(encode, testY)

X_train = X.reshape(X.shape[0], 1, img_rows, img_cols)
X_test = testX.reshape(testX.shape[0], 1, img_rows, img_cols)
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')
X_train /= 255
X_test /= 255
print('X_train shape:', X_train.shape)
print(X_train.shape[0], 'train samples')
print(X_test.shape[0], 'test samples')

Y_train = np_utils.to_categorical(Y, numClasses)
Y_test = np_utils.to_categorical(testY, numClasses)

model = Sequential()

model.add(Convolution2D(32, 3, 3, border_mode='valid', input_shape=(1, 100, 100)))
model.add(Activation(actFunc))
model.add(Convolution2D(32, 3, 3))
model.add(Activation(actFunc))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Convolution2D(64, 3, 3, border_mode='valid'))
model.add(Activation(actFunc))
model.add(Convolution2D(64, 3, 3))
model.add(Activation(actFunc))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(256))
model.add(Activation('relu'))
model.add(Dropout(0.5))

model.add(Dense(numClasses))
model.add(Activation('softmax'))

sgd = SGD(lr=0.1, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy', optimizer=sgd)

print 'Model Compiled'

model.fit(X_train, Y_train, batch_size=batch_size, nb_epoch=nb_epoch, show_accuracy=True, verbose=1, validation_data=(X_test, Y_test))
score = model.evaluate(X_test, Y_test, show_accuracy=True, verbose=0)
pred = model.predict(X_test)

print zip(pred, Y_test)

print('Test score:', score[0])
print('Test accuracy:', score[1])