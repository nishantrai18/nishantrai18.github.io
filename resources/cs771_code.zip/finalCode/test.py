from videoClass import *
import skimage.io as io
import pickle

#Convert images to uint8 to use in imshow and opencv cvtColor functions

#bg = GetBackground('test.mov')
bg = pickle.load(open( "tempBG.p", "rb"))

#pickle.dump(bg, open("tempBG.p", "wb"))
#bg = pickle.load(open( "tempBG.p", "rb"))

graybg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
    
io.imshow(graybg)
io.show()

limit = 40

#Method 1 : Simple Background subtraction
cap = VideoCapture('test.mov')
cap.open()

prev = []
dynBG = graybg
alpha = 0.01

while True:
    ret, frame = cap.read()

    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    cv2.imshow('OrigGray',gray)

    if prev == []:
        prev = gray
    else:
        dynBG = (1-alpha)*dynBG + alpha*gray
    dynBG = dynBG.astype(np.uint8)
    cv2.imshow('DynBG',dynBG)

    frameBG = abs(gray*(1.0) - graybg*(1.0))
    frameDiff = abs(gray*(1.0) - prev*(1.0));

    frameBG = frameBG.astype(np.uint8)
    frameDiff = frameDiff.astype(np.uint8)
    ret, frameBG = cv2.threshold(frameBG, limit, 255, cv2.THRESH_BINARY)           #THRESH_TOZERO, THRESH_BINARY and the INV possible options
    frameBG = frameBG + ((graybg*frameBG)/255.0);
    frameBG = frameBG.astype(np.uint8)
    ret, frameDiff = cv2.threshold(frameDiff, limit, 255, cv2.THRESH_BINARY)           #THRESH_TOZERO, THRESH_BINARY and the INV possible options
    cv2.imshow('FrameDiff',frameDiff)
    cv2.imshow('frame',frameBG)

    '''
    totMask = (frameBG|frameDiff)/(2.0)
    totMask = totMask.astype(np.uint8)
    ret, totMask = cv2.threshold(totMask, limit, 255, cv2.THRESH_BINARY)           #THRESH_TOZERO, THRESH_BINARY and the INV possible options
    cv2.imshow('Mask',totMask)
    '''

    #frame =  frame*(1.0) - bg*(1.0)
    #color = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    prev = gray

cap.release()
cv2.destroyAllWindows()
