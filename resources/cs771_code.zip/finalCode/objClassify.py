
from videoClass import *
import skimage.io as io
import pickle
import datetime
import time
import cv2

from skimage.io import imread,imsave,imshow,show
from skimage.transform import resize
from skimage.feature import hog
import numpy as np
from numpy import zeros, uint8
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.svm import LinearSVC, SVC
from sklearn.decomposition import PCA
from sklearn.externals import joblib

dim = 100
clf = joblib.load('svcCPMB.pkl') 
pixCell = 16
cellBlock = 2
normalize = True

names = ['Car', 'Person', 'Two-Wheeler', 'Two-Wheeler', 'Auto-Rickshaw']

def newNames(name):
	if (name in ['Motorcycle', 'Bicycle', 'Rickshaw']):
		return 'Two-Wheeler'
	else:
		return name

def classifyImg(img):
	img = np.array(img, dtype = np.float16)
	# print img, np.min(img), np.max(img)
	tmpX = hog(img, orientations=8, pixels_per_cell=(pixCell, pixCell), cells_per_block=(cellBlock, cellBlock), transform_sqrt = normalize)
	pred = clf.predict([tmpX])[0]
	conf = clf.decision_function([tmpX])[0]

	tmp = np.fabs(conf)

	# if ((np.max(tmp)/np.sum(tmp)) < 0.4):
	# 	return '?'

	pred = newNames(pred)
	# print pred, conf
	return pred

def getCroppedImage(frame, a, b, c, d, sizeDim):
	if (((abs(a-b) < sizeDim*(0.25)) or ((abs(c-d) < sizeDim*(0.25))))):
		return 'None', 0
	# print frame
	newFrame = frame[a:b,c:d]
	tmpImg = resize(newFrame, (sizeDim, sizeDim))
	tmpImg = skimage.color.rgb2gray(tmpImg)
	return np.array(tmpImg), 1

def RectSim(rectA, rectB):
	left = max(rectA[0], rectB[0])
	right = min(rectA[2], rectB[2])
	bottom = max(rectA[1], rectB[1])
	top = min(rectA[3], rectB[3])
	if (not ((left < right) and (bottom < top))):
		return 0
	area = (top - bottom)*(right - left)
	areaA = (rectA[3] - rectA[1])*(rectA[2] - rectA[0])
	areaB = (rectB[3] - rectB[1])*(rectB[2] - rectB[0])

	#print area, areaA, areaB
	return ((area*(1.0))/max(areaA,areaB))

def GetClosestObj(rect, objList, objRect):
	maxSim = 0
	objID = -1
	for i in range(0, len(objList)):
		tmp = RectSim(rect, objRect[i])
		if (tmp > maxSim):
			maxSim = tmp
			objID = objList[i]
	return objID, maxSim

#bg = GetBackground('test2.mov')
#bg = pickle.load(open( "tempBG.p", "rb"))

#pickle.dump(bg, open("tempBG2.p", "wb"))
bg = pickle.load(open( "tempBG.p", "rb"))

areaThreshold = 2000
redFact = 0.5
graybg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
graybg = cv2.resize(graybg ,None, fx=redFact, fy=redFact)
	
io.imshow(graybg)
io.show()

# cap = VideoCapture('videosample5.mov')
cap = VideoCapture('test.mov')
cap.open()

freeIDS = set([0,1,2,3,4,5])			#List of freeIDs
objList = []		# List of valid detected objects, use it in marking the entities
objRect = []		# List of the respective contours of the objects
colorList = [(125, 125, 125), (125, 125, 0), (0, 125, 0), (0, 255, 125), (125, 255, 0), (0, 255, 255), (255, 255, 0)]
numObj = len(colorList)

for i in range(0,110):
	(grabbed, frame) = cap.read()
	# Ignore the first 10 frames, mostly due to noise

while True:
	(grabbed, frame) = cap.read()
	text = "Nothing"

	if not grabbed:
		break

	t1 = time.time()

	frame = cv2.resize(frame ,None, fx= redFact, fy=redFact)
  
	# resize the frame, convert it to grayscale, and blur it
	#frame = imutils.resize(frame, width=500)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	#cv2.imshow('OrigGray',gray)
	#gray = cv2.GaussianBlur(gray, (5, 5), 3)
	# compute the absolute difference between the current frame and first frame

	frameDelta = cv2.absdiff(graybg, gray)
	thresh = cv2.threshold(frameDelta, 50, 255, cv2.THRESH_BINARY)[1]
 
	# dilate the thresholded image to fill in holes, then find contours on thresholded image

	thresh = cv2.GaussianBlur(thresh, (5, 5), 3)
	# cv2.imshow('OrigThresh', thresh)

	'''
	thresh = cv2.dilate(thresh, None, iterations = 4)
	cv2.imshow('DilateThresh', thresh)

	thresh = cv2.GaussianBlur(thresh, (5, 5), 3)
	cv2.imshow('BlurThresh', thresh)
	'''

	kernel = np.ones((5,5),np.uint8)
	thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations = 2)
	# cv2.imshow('MorphClose', thresh)
	thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations = 3)
	# cv2.imshow('MorphOpen', thresh)

	(cnts, _) = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	cv2.drawContours(gray, cnts, -1, (0,255,0), 3)
	# cv2.imshow('DrawCont', gray)

	newObjID = []
	newObjRect = []

	for c in cnts:
		if cv2.contourArea(c) < areaThreshold*((redFact/0.25)**2):					# if the contour is too small, ignore it
			continue

		(x, y, w, h) = cv2.boundingRect(c)				# compute the bounding box for the contour, draw it on the frame, and update the text
		cRect = (x, y, x + w, y + h)
		objID, maxSim = GetClosestObj(cRect, objList, objRect)				#max Sim refers to the similarity between the nearest object. Can be used to detect new objects
		
		if ((maxSim < 0.65) or (objID < 0)):
			if (len(freeIDS) > 0):
				objID = next(iter(freeIDS))
			else:
				print "ERROR: No more free IDs left"
				input("Waiting for further action")

		newImg, stat = getCroppedImage(frame, y, y+h, x, x+w, dim)
		if stat:
			# cv2.imshow("Cropped objects", resize(newImg,(500,500)))
			className = classifyImg(newImg)
			cv2.putText(frame, className, (x+w, y+h), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
			# print className

		cv2.rectangle(frame, (x, y), (x + w, y + h), colorList[objID], 2)
		text = "Not Empty"

		newObjID.append(objID)
		newObjRect.append(cRect)

	for o in objList:
		freeIDS.add(o)

	# Update the object lists
	objList = newObjID
	objRect = newObjRect

	for o in set(objList):
		freeIDS.remove(o)
	
	text += ' : '
	for ids in objList:
		text += str(ids) + ', '

	cv2.putText(frame, "Gate Status: {}".format(text), (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

	print 'Time taken is', time.time()-t1
	
	cv2.imshow("Detected objects", frame[:,:,::-1])
	#cv2.imshow("Thresh", thresh)
	#cv2.imshow("Frame Delta", frameDelta)
	key = cv2.waitKey(1) & 0xFF
 	
	# if the `q` key is pressed, break from the lop
	if key == ord("q"):
		break
	elif key == ord("p"):
		input("PAUSED FOR NOW... Enter 0-9 to continue")

cap.release()
cv2.destroyAllWindows()