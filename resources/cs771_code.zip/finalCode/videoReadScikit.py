from skvideo.io import VideoCapture
import numpy as np
import cv2

cap = VideoCapture('test.mov')
cap.open()

print cap
print cap.width, cap.height

while True:
    retval, image = cap.read()    
    if not retval:
        break

print "Done"