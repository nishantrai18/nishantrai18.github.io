from videoClass import *
import skimage.io as io
import pickle
import datetime
import time
import cv2

#Convert images to uint8 to use in imshow and opencv cvtColor functions

bg = GetBackground('videosample5.mov')
#bg = pickle.load(open( "tempBG.p", "rb"))

pickle.dump(bg, open("tempBG3.p", "wb"))
# bg = pickle.load(open( "tempBG.p", "rb"))

graybg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
graybg = cv2.resize(graybg ,None, fx=0.25, fy=0.25)
	
io.imshow(graybg)
io.show()

input('WAIT')

#Method 1 : Simple Background subtraction
#With Simple Object Detection

cap = VideoCapture('test.mov')
cap.open()



'''
while True:
	ret, frame = cap.read()
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	cv2.imshow('OrigGray',gray)

	img_filt = cv2.medianBlur(gray, 5)
	img_th = cv2.adaptiveThreshold(img_filt,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)
	contours, hierarchy = cv2.findContours(img_th, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

	#print len(contours)
	#print hierarchy

	cv2.imshow('medBlur',img_filt)
	cv2.imshow('adapThres',img_th)
	#cv2.imshow('contours',contours)

	gray = img_filt
	frame =  gray*(1.0) - graybg*(1.0)
	frame[frame<0] = 0
	frame = frame.astype(np.uint8)
	ret, frame = cv2.threshold(frame, 50, 255, cv2.THRESH_BINARY)			#THRESH_TOZERO, THRESH_BINARY and the INV possible options
	#color = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	cv2.imshow('frame',frame)
	if cv2.waitKey(1) & 0xFF == ord('q'):
		break
'''

# loop over the frames of the video
while True:
	# grab the current frame and initialize the occupied/unoccupied
	# text
	(grabbed, frame) = cap.read()
	text = "Unoccupied"

	# if the frame could not be grabbed, then we have reached the end
	# of the video
	if not grabbed:
		break

	frame = cv2.resize(frame ,None, fx=0.25, fy=0.25)
  
	# resize the frame, convert it to grayscale, and blur it
	#frame = imutils.resize(frame, width=500)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	#cv2.imshow('OrigGray',gray)

	#gray = cv2.GaussianBlur(gray, (5, 5), 3)

	# compute the absolute difference between the current frame and
	# first frame

	frameDelta = cv2.absdiff(graybg, gray)
	thresh = cv2.threshold(frameDelta, 50, 255, cv2.THRESH_BINARY)[1]
 
	# dilate the thresholded image to fill in holes, then find contours
	# on thresholded image

	thresh = cv2.GaussianBlur(thresh, (5, 5), 3)

	cv2.imshow('OrigThresh', thresh)

	thresh = cv2.dilate(thresh, None, iterations = 4)

	cv2.imshow('DilateThresh', thresh)

	thresh = cv2.GaussianBlur(thresh, (5, 5), 3)

	cv2.imshow('BlurThresh', thresh)

	kernel = np.ones((5,5),np.uint8)
	thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations = 2)

	cv2.imshow('MorphThresh', thresh)

	tmpImg = thresh.copy()
	cnts, _ = cv2.findContours(tmpImg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	cv2.imshow('Cont', tmpImg)

	cv2.drawContours(gray, cnts, -1, (0,255,0), 3)
	cv2.imshow('DrawCont', gray)

	# loop over the contours
	for c in cnts:
		# if the contour is too small, ignore it
		if cv2.contourArea(c) < 2500:
			continue
 
		# compute the bounding box for the contour, draw it on the frame,
		# and update the text
		(x, y, w, h) = cv2.boundingRect(c)
		cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
		text = "Not Empty"
	
	# draw the text and timestamp on the frame
	cv2.putText(frame, "Gate Status: {}".format(text), (10, 20),
		cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
	cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S%p"),
		(10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1)
 
	# show the frame and record if the user presses a key
	cv2.imshow("Security Feed", frame)
	#cv2.imshow("Thresh", thresh)
	#cv2.imshow("Frame Delta", frameDelta)
	key = cv2.waitKey(1) & 0xFF
 
	# if the `q` key is pressed, break from the lop
	if key == ord("q"):
		break

cap.release()
cv2.destroyAllWindows()