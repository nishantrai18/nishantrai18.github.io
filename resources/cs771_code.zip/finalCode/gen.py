import cv2
import os, glob
from operator import itemgetter, attrgetter
from skvideo.io import VideoCapture

'''
make a directory and update dirPose with its name to store images in that folder
change the paramenter of line 14 and line 23 with the fileName of the video
update line 37 with the feature to extract
'''

dirPosList = ['Car', 'Person', 'Motorcycle', 'Bicycle', 'Number-plate', 'Autorickshaw', 'Rickshaw']

dirPos = "imageData"

if not os.path.exists(dirPos):
	os.makedirs(dirPos)

for x in dirPosList:
	if not os.path.exists(dirPos + '/' + x):
		os.makedirs(dirPos + '/' + x)

# if not os.path.exists(dirNeg):
#     os.makedirs(dirNeg)

for fileName in list(glob.glob("data/*.mov")):

	if ('videosample' not in fileName):
		continue

	print fileName
	vc = VideoCapture(fileName)
	vc.open()

	if vc.isOpened():
		rval , frame = vc.read()
	else:
		raw_input('Not opened. What To do?')
		rval = False

	print 'Datafile is', (fileName.strip('.mov').split('/')[1]) + '.txt'

	dataFile = open('labels/' + (fileName.strip('.mov').split('/')[1]) + '.txt')
	imageData = dataFile.read()
	imageData = imageData.split("\n")

	pos = 1

	#Entries corresponding to the required feature.
	# print len(imageData)
	objId = {}
	oldId = {}
	posId = {}
	oldframe = {}
	for x in dirPosList:
		objId[x] = -1
		oldId[x] = -1
		posId[x] = []
		oldframe[x] = []

	entries={}
	for i in range(0,len(imageData)-1):
		
		temp = imageData[i].split(" ")
		objClass = temp[9].strip('\"')
		
		if(objClass in dirPosList):
			
			if(oldId[objClass] != int(temp[0])):
				objId[objClass] += 1
				oldframe[objClass].append([int(temp[1]),int(temp[2]),int(temp[3]),int(temp[4])])
				oldId[objClass] = int(temp[0])
				posId[objClass].append(0)
			
			temp[0] = objId[objClass]
			temp[5] = int(temp[5])

			if (objClass not in entries):
				entries[objClass] = []
			else:
				entries[objClass].append(temp)

	# Maybe this isn't necessary
	for key in entries.keys():
		entries[key] = sorted(entries[key], key=itemgetter(5))

	# for i in entries:
	# 	print i

	thresLim = 4
	i = {}
	for x in dirPosList:
		i[x] = 0
	
	frameNo = 0

	# print carid
	# print len(entries)
	while rval:
		# print frameNo
		for obj in dirPosList:
			
			# print obj

			if (obj not in entries):
				continue

			# print obj, i[obj], len(entries[obj])

			while (i[obj] < len(entries[obj]) and entries[obj][i[obj]][5] == frameNo):
				temp = entries[obj][i[obj]]

				# print 'temp'

				if (int(temp[7]) != '1' and int(temp[6]) != '1'):
					# print "test"
					imageName = obj + str(temp[0])+"_"+ str(posId[obj][temp[0]]) + ".jpg"
					
					x1 = int(temp[1])
					y1 = int(temp[2])
					x2 = int(temp[3])
					y2 = int(temp[4])
					oldx1=oldframe[obj][temp[0]][0]
					oldy1=oldframe[obj][temp[0]][1]
					oldx2=oldframe[obj][temp[0]][2]
					oldy2=oldframe[obj][temp[0]][3]

					if((abs(oldx1-x1)>thresLim and abs(oldx2-x2)>thresLim) and (abs(oldy1-y1)>thresLim and abs(oldy2-y2)>thresLim) \
						and (abs(oldx1-x1)>thresLim and abs(oldy1-y1)>thresLim) and (abs(oldx2-x2)>thresLim and abs(oldy2-y2)>thresLim)):
						
						print i
						# print y1, y2, x1, x2
						newFrame = frame[y1:y2, x1:x2]
						print os.path.join(dirPos + '/' + obj, imageName)

						# print len(newFrame)
						# print len(newFrame[0])
						# print len(newFrame[0][0])

						b,g,r = cv2.split(newFrame)       # get b,g,r
						newFrame = cv2.merge([r,g,b])     # switch it to rgb

						cv2.imwrite(os.path.join(dirPos + '/' + obj, imageName), newFrame)
						posId[obj][temp[0]] += 1
						oldframe[obj][temp[0]][0]=x1
						oldframe[obj][temp[0]][1]=y1
						oldframe[obj][temp[0]][2]=x2
						oldframe[obj][temp[0]][3]=y2
						
				i[obj] += 1

		# if(i[obj] >= len(entries[obj])):
		# 	break
		# carIndex += 1
		# cv2.waitKey(1)

		frameNo = frameNo + 1
		rval, frame = vc.read()



	# testFile = open("test.txt","w")
	# testFile.write(str(pos) + " " + str(neg) + " " + str(frameNo))
	vc.release()
